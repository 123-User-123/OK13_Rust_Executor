use jni::sys::jint;
use std::sync::Once;

static INIT: Once = Once::new();

#[no_mangle]
pub extern "system" fn JNI_OnLoad(_vm: *mut jni::sys::JavaVM, _: *mut std::os::raw::c_void) -> jint {
    INIT.call_once(|| {
        std::thread::spawn(|| {
            std::thread::sleep(std::time::Duration::from_secs(3));
            crate::gui::start_gui();
        });
    });
    0x00010006 // JNI_VERSION_1_6
}