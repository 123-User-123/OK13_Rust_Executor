use mlua::{Lua, Result};

static mut GLOBAL_LUA: Option<Lua> = None;

pub fn init_lua_state(ptr: usize) -> Result<()> {
    unsafe {
        GLOBAL_LUA = Some(Lua::unsafe_new_with_stdlib(ptr as _));
    }
    Ok(())
}

pub fn execute(code: &str) -> Result<()> {
    unsafe {
        if let Some(lua) = &GLOBAL_LUA {
            lua.load(code).exec()
        } else {
            Err(mlua::Error::external("Lua state yok"))
        }
    }
}