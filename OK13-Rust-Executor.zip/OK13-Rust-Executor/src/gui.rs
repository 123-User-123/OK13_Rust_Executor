use eframe::{egui, App, Frame};
use std::sync::atomic::{AtomicBool, Ordering};

static mut EXECUTE_CODE: Option<String> = None;

pub fn start_gui() {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([520.0, 320.0])
            .with_resizable(false)
            .with_transparent(true)
            .with_decorations(false),
        ..Default::default()
    };

    eframe::run_native(
        "OK-13 Executor",
        options,
        Box::new(|_| Box::new(OK13GUI::default())),
    );
}

struct OK13GUI {
    code: String,
    tab: usize,
}

impl Default for OK13GUI {
    fn default() -> Self {
        Self {
            code: "// Kod Girin...".to_string(),
            tab: 0,
        }
    }
}

impl App for OK13GUI {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.selectable_value(&mut self.tab, 0, "Kod Alanı");
                ui.selectable_value(&mut self.tab, 1, "Script Ara");
                ui.selectable_value(&mut self.tab, 2, "Kaydet");
            });

            ui.separator();

            match self.tab {
                0 => {
                    ui.text_edit_multiline(&mut self.code);
                    ui.horizontal(|ui| {
                        if ui.button("Çalıştır").clicked() {
                            let _ = crate::lua_vm::execute(&self.code);
                        }
                        if ui.button("Temizle").clicked() {
                            self.code = "// Kod Girin...".to_string();
                        }
                    });
                }
                _ => ui.label("Yakında eklenecek..."),
            }
        });
    }
}